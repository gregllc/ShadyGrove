import java.io.*;
import java.util.*;

import javafx.scene.image.Image;

// no file not found implimented 
public class Student {
    String path;
    String first;
    String last;
    String ids;
    PrintStream student;
    ArrayList<String> subjects = new ArrayList<String>();

    public static int id = 0;
    public Student(String first, String last) throws FileNotFoundException{
        String[] subjects = {"Math:-", "English:-", "Science:-", "Reading/ Writing:-"};
        path = first+ ":" + last + ":" + id;
        this.first = first;
        this.last = last;
        ids = String.valueOf(id);
        File folder = new File(path);
        folder.mkdir();
        student =new PrintStream(new FileOutputStream(new File(folder, first+ ":" + last + ".txt")));
        for(String subject : subjects){
            student.println(subject); 
        }

        addStudent(path);
        id = id+1;
    }

    public Student(String data){// throws FileNotFoundException{
        String[] student = data.split(":");
        this.first = student[0];
        this.last = student[1];
        ids = student[2];
        path = first+ ":" + last + ":" + student[2];
    }

    public String getStudentName(){
        return first + " " + last + " ID#" + ids;
    }

    public String getPath(){
        return path;
    }

    public String getStudentImage(){
        return path + "/" + first+ last + ".png";
    }

    private String getFile(){
        return path + "/" + first+ ":" + last + ".txt";
    }
    
    public ArrayList<String> readFile()
    {
        ArrayList<String> sublist = new ArrayList<>();
        try
        {
            Scanner fscan = new Scanner(new File(getFile()));
            
            while (fscan.hasNext()){
                    sublist.add(fscan.next());
            }
            fscan.close();
            //System.out.println(fldata);
        }
        catch(IOException e){}
        return sublist;
    }

    public ArrayList<String> updateFile(String subject, String text){
        System.out.println(subject);
        System.out.println(text);
        ArrayList<String> subs = readFile();
        System.out.println(subs);
        subjects.clear();
        for(String sub : subs){
            System.out.println(sub + ";");
            Object[] data = sub.split(":");
                    System.out.println(data[0]);
                    System.out.println(data[1]);
                    if(subject.equals(data[0])){
                        data[1] = text;
                        
                    }
            subjects.add(data[0]+":"+data[1]);
        }
        
        try{    
            student =new PrintStream(new FileOutputStream(getFile()));
            for(String results : subjects){
                student.println(results);
            }
        }
        catch(IOException ioe){}
        return subjects;
    }

    //cahange to boolean
    private void copyFileUsingStream(String dest) throws IOException {
        PrintStream os;
        String destination = "Archive/" +dest+".txt";
        try {
            Scanner fscan = new Scanner(new File(getFile()));
            os = new PrintStream(new FileOutputStream(new File(destination)));
            while (fscan.hasNext()) {
                os.println(fscan.next());
            }
            fscan.close();
            os.close();
        } finally {
            
        }
    }
    public void archive_delete() throws IOException{
        copyFileUsingStream(getPath());
        try{
            File file = new File(getFile());
            file.delete();
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }

    private void addStudent(String name){
            ArrayList<String> studentlist = new ArrayList<>();
            try
            {
                //fldata.clear();
                Scanner sscan = new Scanner(new File("students.txt"));
                
                while (sscan.hasNext()){
                        studentlist.add(sscan.next());
                }
                sscan.close();
                //System.out.println(fldata);
            }
            catch(IOException e){}

            studentlist.add(name);
            try{    
                PrintStream file =new PrintStream(new FileOutputStream("students.txt"));
                for(String student: studentlist){
                    file.println(student);
                }
                file.close();
            }
            catch(IOException ioe){}
            
    
        }
    

}
