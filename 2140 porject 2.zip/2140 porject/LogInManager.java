import java.util.*;
import java.io.*;

public class LogInManager {

    String principal = "principal";

    public String getLogin(){
        return "Login.txt";
    }

    public boolean login(String username, String password){
        ArrayList<String> logindata = readFile();
        if(logindata.contains(username+ ":" + password)){
            return true;
        }
        return false;
    }

    private ArrayList<String> readFile()
    {
        ArrayList<String> logindata = new ArrayList<String>();
        try
        {
            Scanner fscan = new Scanner(new File(getLogin()));
            
            while (fscan.hasNext()){
                    logindata.add(fscan.next());
            }
            fscan.close();
            //System.out.println(fldata);
        }
        catch(IOException e){}
        return logindata;
    }

    public boolean addlogin(String username, String password) throws FileNotFoundException{
        ArrayList<String> logindata = readFile();
        if(logindata.contains(username+ ":" + password)){
            return false;
        }else{
            PrintStream loglist=new PrintStream(new FileOutputStream("Login.txt"));
            for(String login : logindata){
                loglist.println(login);
            }
            loglist.println(username+ ":" + password);
            loglist.close();
        }
        return false;
    }

    public boolean isPrincipal(String username){
        if(username.equals("principal")){
            return true;
        }
        return false;
    }

    public boolean isParent(String username){
        if(username.equals("guest")){
            return true;
        }else{return false;}
    }
}
