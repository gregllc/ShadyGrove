import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
 
class Principal extends Teacher {
  private static final int BORDER = 12;  
    private static final int GAP    = 5;
    private static ArrayList<String> studentdata = new ArrayList<String>();


    public void principalmenu() throws FileNotFoundException{
          JPanel prinpanel = teachermenu();
          JMenu menu;
          JMenuItem i1, i2, i3;  
          JFrame f= new JFrame("Shady Grove");  
          JMenuBar mb=new JMenuBar();  
          menu=new JMenu("Menu");    
          i1=new JMenuItem("Add Student");  
          i1.addActionListener(new ActionListener(){ 
            public void actionPerformed(ActionEvent ev){
                f.setContentPane(addStudent());
                f.repaint();
              }});
          i2=new JMenuItem("Logout"); 
          i2.addActionListener(new ActionListener(){ 
            public void actionPerformed(ActionEvent ev){
                /* log out gui call */}});   
          i3= new JMenuItem("Archive/ Delete");
          i3.addActionListener(new ActionListener(){ 
            public void actionPerformed(ActionEvent ev){
                try {
                  f.setContentPane(archivemenu());
                  f.repaint();
                } catch (FileNotFoundException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
                }}});  
          menu.add(i1); menu.add(i2); menu.add(i3);
          mb.add(menu);  
          f.setJMenuBar(mb);  
          f.setSize(400,400);  
          f.setLayout(null);
          f.setContentPane(prinpanel);
          f.setVisible(true);


        //return f;

    }


    private class ButtonListener implements ActionListener
    {
     @Override
      public void actionPerformed(ActionEvent ev){
            Object student = ev.getSource();
            String name = student.toString();
            String[] data = name.split("text");
            name = data[1];
            data = name.split(",");
            name = data[0];
            data = name.split("=");
            name = data[1];
            data = name.split(" ");
            data[2] = data[2].replaceAll("ID#", "");
            name = data[0]+":"+ data[1]+ ":" + data[2];
            
            Student student2 = new Student(name);
            try {
              student2.archive_delete();
            } catch (IOException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
            }
            //teach.setContentPane(studentmenu(name));
            teach.setSize(800,800);
            teach.repaint();
            //h.setVisible(true);

        }
    }
    
    public JPanel archivemenu() throws FileNotFoundException{
        JPanel content = new JPanel(new GridBagLayout());
        content.setBorder(BorderFactory.createEmptyBorder(BORDER, BORDER, 
        BORDER, BORDER));
        JPanel listJPanel= new JPanel(new GridBagLayout());
        listJPanel.setBorder(BorderFactory.createEmptyBorder(BORDER, BORDER, 
                    BORDER, BORDER));

        JScrollPane asp = new JScrollPane(listJPanel);
        listStudents();
        
        ButtonListener buttonlistener = new ButtonListener();

        for(String student: studentdata){
            Student stud = new Student(student);
            x = new JButton(new ImageIcon(stud.getStudentImage()));
            x.setText(stud.getStudentName());
            x.addActionListener(buttonlistener);
            //x.setPreferredSize(new Dimension(100,100));
            listJPanel.add(x, pos.nextRow().expandW());
        }

        content.setBorder(BorderFactory.createEmptyBorder(BORDER, BORDER, 
                    BORDER, BORDER));

        asp.setSize(200, 70);

        asp.add(listJPanel);
        JLabel search = new JLabel("Search");
        
            content.add(search, pos.nextCol());
            content.add(searchtf, pos.nextCol().expandW().expandW());
            content.add(new Gap(GAP), pos.nextCol());
            //content.add(cb, pos.nextCol());
            content.add(listJPanel, pos.nextRow().width());
            content.setSize (400, 130);

            
        return content;
    }

    private String getStudentList(){
      return "students.txt"; 
  }


  private void listStudents()
  {
      try
      {
          //fldata.clear();
          Scanner sscan = new Scanner(new File(getStudentList()));
          
          while (sscan.hasNext()){
                  studentdata.add(sscan.next());
          }
          sscan.close();
          //System.out.println(fldata);
      }
      catch(IOException e){}

  }

}
